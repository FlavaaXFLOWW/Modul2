import { createRouter, createWebHistory } from "vue-router";
import Home from "../views/home.vue";
import PostsIndex from "../views/posts/index.vue";
import PostsCreate from "../views/posts/create.vue";

const routes = [
    { path: "/", name: "home", component: Home },
    { path: "/posts", name: "posts.index", component: PostsIndex },
    { path: "/posts/create", name: "posts.create", component: PostsCreate },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;

